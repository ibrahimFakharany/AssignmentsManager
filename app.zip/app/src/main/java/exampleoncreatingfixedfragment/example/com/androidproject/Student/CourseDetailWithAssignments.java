package exampleoncreatingfixedfragment.example.com.androidproject.Student;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import exampleoncreatingfixedfragment.example.com.androidproject.R;

public class CourseDetailWithAssignments extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail_with_assignments);
    }
}
