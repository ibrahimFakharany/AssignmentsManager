package exampleoncreatingfixedfragment.example.com.androidproject;

/**
 * Created by 450 G1 on 09/05/2017.
 */
public class Params {
    String name;
    String value;

    public Params(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }
}
